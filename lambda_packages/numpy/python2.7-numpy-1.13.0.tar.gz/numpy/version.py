
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.13.0'
version = '1.13.0'
full_version = '1.13.0'
git_revision = 'e94ed84010c60961f82860d146681d3fd607de4e'
release = True

if not release:
    version = full_version
