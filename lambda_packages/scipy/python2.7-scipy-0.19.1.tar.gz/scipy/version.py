
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.19.1'
version = '0.19.1'
full_version = '0.19.1'
git_revision = '03b1092cf0e0bdebcbe98a44d289208a1e597416'
release = True

if not release:
    version = full_version
